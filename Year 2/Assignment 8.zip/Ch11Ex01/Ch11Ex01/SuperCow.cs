﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      SuperCow.cs
//Description:       this is the Super Cow class, it can do anything a cow can do and more. It inherits from cow.
//                   The has a new sound and a new method to fly!
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    //inherits from Cow
    public class SuperCow : Cow
    {
        //super cow can fly, so hes got a method to allow him to!
        public void Fly()
        {
            Console.WriteLine("{0} is flying!", name);
        }

        //calls the parameterized constructor in the base class
        public SuperCow(string newName)
            : base(newName)
        {
        }

        //method that was required because of the interface in Animal
        public override void MakeANoise()
        {
            Console.WriteLine(
               "{0} says 'here I come to save the day!'", name);
        }
    }
}
