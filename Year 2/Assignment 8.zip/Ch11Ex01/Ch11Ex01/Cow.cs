﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      Cow.cs
//Description:       this is the Cow class, it holds information specific to a Cow. Inherits from Animal class
//                   Can feed, milk and have a cow make a sound.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    //inherits from Cow
    public class Cow : Animal
    {
        //This is a method that returns nothing
        public void Milk()
        {
            Console.WriteLine("{0} has been milked.", name);
        }

        //this is a parameterized constructor that calls the base constructor passing it newName
        public Cow(string newName)
            : base(newName)
        {
        }
        //this is the interface that was set up inside of animal
        //This is required to for the class to work since the interface was defined
        public override void MakeANoise()
        {
            Console.WriteLine("{0} says 'moo!'", name);
        }
    }
}
