﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      program.cs
//Description:       This tests the Farm, Animal, Cow, Chicken and SuperCow class

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    class Program
    {
        static void Main(string[] args)
        {
            //create a new farm list of animals
            Farm<Animal> farm = new Farm<Animal>();
            //add different type of animals to the list
            farm.Animals.Add(new Cow("Jack"));
            farm.Animals.Add(new Chicken("Vera"));
            farm.Animals.Add(new Chicken("Sally"));
            farm.Animals.Add(new SuperCow("Kevin"));
            //have all animals make sound
            farm.MakeNoises();

            //make a new farm for cows only
            Farm<Cow> dairyFarm = farm.GetCows();
            //feed all the animals in the dairyfarm
            dairyFarm.FeedTheAnimals();

            // go through all the cows and checks if they are a sub class of cow(super cow)
            foreach (Cow cow in dairyFarm)
            {
                //checks if SuperCow
                if (cow is SuperCow)
                {
                    //uses the Fly() method
                    (cow as SuperCow).Fly();
                }
            }
            //wait for user to type something
            Console.ReadKey();
        }
    }
}