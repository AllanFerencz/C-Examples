﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      Chicken.cs
//Description:       this is the Chicken class, it holds information specific to a Chicken. Inherits from Animal class.
//                   can LayEgg, feed and make a sound

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    //inherits Animal
    public class Chicken : Animal
    {
        //layEgg method that returns nothing but writes to console
        public void LayEgg()
        {
            Console.WriteLine("{0} has laid an egg.", name);
        }

        //parameterized constructor that calls the base class(Animal)
        public Chicken(string newName)
            : base(newName)
        {
        }
        //interface that was set up in the base class(animal)
        public override void MakeANoise()
        {
            Console.WriteLine("{0} says 'cluck!';", name);
        }
    }
}