﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      Animal.cs
//Description:       This is the Animal class, you can not ceate an "Animal" object but you can inherit from this class.
//                   Since animals have things in common that information is filled in here.
//                   can set name and feed and animal

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    public abstract class Animal
    {
        //Holds the name of the Animal
        protected string name;

        //sets the name of the animal
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        //Default animal Constructor
        public Animal()
        {
            name = "The animal with no name";
        }

        //Parameterized constructor
        public Animal(string newName)
        {
            name = newName;
        }

        //This is an interface that every class that inherits from this one needs
        public abstract void MakeANoise();

        //this is a feed method
        public void Feed()
        {
            Console.WriteLine("{0} has been fed.", name);
        }
    }
}
