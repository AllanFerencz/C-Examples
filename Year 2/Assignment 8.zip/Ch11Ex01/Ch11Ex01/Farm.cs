﻿//Name:              Allan Ferencz
//Date:              March 13, 2015
//Program Name:      farm.cs
//Description:       this is a list class. It holds different kinds of animals. it can make all the animals make sound, get feed and can get the cows.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch12Ex04
{
    //A class that holds Animals also uses IEnumerable
    public class Farm<T> : IEnumerable<T>
       where T : Animal
    {
        //create a list of that holds animals
        private List<T> animals = new List<T>();

        //returns an animal 
        public List<T> Animals
        {
            get
            {
                return animals;
            }
        }

        //returns the index in the list the animal is
        public IEnumerator<T> GetEnumerator()
        {
            return animals.GetEnumerator();
        }
        
        //required since we are using IEnumerable 
        IEnumerator IEnumerable.GetEnumerator()
        {
            return animals.GetEnumerator();
        }

        //has all the animals make sound
        public void MakeNoises()
        {
            //loops through all the animals 
            foreach (T animal in animals)
            {
                //calls the animal class interface for all the sounds for the different animals
                animal.MakeANoise();
            }
        }

        //feeds all the animals
        public void FeedTheAnimals()
        {
            //loops through all the animals 
            foreach (T animal in animals)
            {
                //calls the animal class Feed that works for all the other class
                animal.Feed();
            }
        }

        //method to sort out all the cows
        public Farm<Cow> GetCows()
        {
            //create a list that only holds cows
            Farm<Cow> cowFarm = new Farm<Cow>();
            //loop through all the animals
            foreach (T animal in animals)
            {
                //checks if the animal is a cow 
                if (animal is Cow)
                {
                    //adds the animal to the new cow list
                    cowFarm.Animals.Add(animal as Cow);
                }
            }
            //return the list
            return cowFarm;
        }
    }
}