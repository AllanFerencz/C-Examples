﻿//Name:              Allan Ferencz
//Date:              March 6, 2015
//Program Name:      Card.cs
//Description:       shows how to use the card class in a way to find out if you have a flush or not.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ch11CardLib
{
    public class Card : ICloneable
    {
        /// <summary>
        /// Flag for trump usage. If true, trumps are valued higher
        /// than cards of other suits.
        /// </summary>
        public static bool useTrumps = false;

        /// <summary>
        /// Trump suit to use if useTrumps is true.
        /// </summary>
        public static Suit trump = Suit.Club;

        /// <summary>
        /// Flag that determines whether aces are higher than kings or lower
        /// than deuces.
        /// </summary>
        public static bool isAceHigh = true;

        //copy constructor
        public object Clone()
        {
            return MemberwiseClone();
        }

        //holds the rank of a card
        public readonly Rank rank;
        //holds the suit of a card
        public readonly Suit suit;

        //constructor to instantiate a new card
        public Card(Suit newSuit, Rank newRank)
        {
            //sets the suit past to it to the suit in the class
            suit = newSuit;
            //sets the rank past to it to the rnak in the class
            rank = newRank;
        }

        //default constructor
        private Card()
        {
        }

        //meathod for returning the rank and suit of the card
        public String ToString()
        {
            return "The " + rank + " of " + suit + "s";
        }
        //overload the equality operator to check it the cards are the same
        public static bool operator ==(Card card1, Card card2)
        {
            return (card1.suit == card2.suit) && (card1.rank == card2.rank);
        }

        //overload the not equal to operator to check it the cares are not the same using the overloaded equality constructor
        public static bool operator !=(Card card1, Card card2)
        {
            return !(card1 == card2);
        }

        //overload .equals to compare the object to the one past to it
        public override bool Equals(object card)
        {
            return this == (Card)card;
        }
        
        //overload the GetHashCode to see if the memory address of the object
        public override int GetHashCode()
        {
            return 13 * (int)suit + (int)rank;
        }

        //overload the  greater than operator
        public static bool operator >(Card card1, Card card2)
        {
            //checks if suits are the same
            if (card1.suit == card2.suit)
            {
                //checks if ace has been set to high
                if (isAceHigh)
                {
                    //checks if card 1 is an ace
                    if (card1.rank == Rank.Ace)
                    {
                        //checks if card 2 is an ace
                        if (card2.rank == Rank.Ace)
                            return false;
                        else
                            return true; // returns true since it is grater than
                    }
                    else
                    {
                        //checks if card 2 is an ace
                        if (card2.rank == Rank.Ace) 
                            return false;
                        else
                             //compares the rank number using the default greater than operator
                            return (card1.rank > card2.rank);
                    }
                }
                else
                {
                    //compares the rank number using the default greater than operator, since the ace is actually 1
                    return (card1.rank > card2.rank);
                }
            }
            else
            {
                //checks is use trump is true and suit of card 2 is equal to trump suit
                if (useTrumps && (card2.suit == Card.trump))
                    return false;
                else
                    return true;
            }
        }

        //checks if less then by using the greater than or equal to operator
        public static bool operator <(Card card1, Card card2)
        {
            return !(card1 >= card2);
        }


        //overload the  greater than or equal operator 
        public static bool operator >=(Card card1, Card card2)
        {

            //checks if suits are the same
            if (card1.suit == card2.suit)
            {
                //checks if ace is high
                if (isAceHigh)
                {
                    //checks if card one is an ace
                    if (card1.rank == Rank.Ace)
                    {
                        return true;
                    }
                    else
                    {
                        //checks if card 2 is a ace
                        if (card2.rank == Rank.Ace)
                            return false;
                        else
                            //compares the rank number using the default greater than or equal to operator
                            return (card1.rank >= card2.rank);
                    }
                }
                else
                {
                    //compares the rank number using the default greater than or equal to operator
                    return (card1.rank >= card2.rank);
                }
            }
            else
            {
                //checks is use trump is true and suit of card 2 is equal to trump suit
                if (useTrumps && (card2.suit == Card.trump))
                    return false;
                else
                    return true;
            }
        }
        //checks if less then by using the greater than operator
        public static bool operator <=(Card card1, Card card2)
        {
            return !(card1 > card2);
        }
    }
}
