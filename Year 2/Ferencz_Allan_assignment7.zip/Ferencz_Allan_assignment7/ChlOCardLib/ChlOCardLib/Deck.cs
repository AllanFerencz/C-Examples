﻿//Name:              Allan Ferencz
//Date:              March 6, 2015
//Program Name:      deck.cs
//Description:       This enumeration picks sets the standard for suits

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ch11CardLib
{
    public class Deck : ICloneable
    {

        /// <summary>
        /// Nondefault constructor. Allows aces to be set high.
        /// </summary>
        public Deck(bool isAceHigh)
            : this()
        {
            Card.isAceHigh = isAceHigh;
        }

        /// <summary>
        /// Nondefault constructor. Allows a trump suit to be used.
        /// </summary>
        public Deck(bool useTrumps, Suit trump)
            : this()
        {
            Card.useTrumps = useTrumps;
            Card.trump = trump;
        }
        /// <summary>
        /// Nondefault constructor. Allows aces to be set high and a trump suit
        /// to be used.
        /// </summary>
        public Deck(bool isAceHigh, bool useTrumps, Suit trump)
            : this()
        {
            Card.isAceHigh = isAceHigh;
            Card.useTrumps = useTrumps;
            Card.trump = trump;
        }

        //copy constructor
        public object Clone()
        {
            Deck newDeck = new Deck(cards.Clone() as Cards);
            return newDeck;
        }

        //copy constructor
        private Deck(Cards newCards)
        {
            cards = newCards;
        }

        //list of cards
        private Cards cards = new Cards();

        //constructor to set the cards in a deck
        public Deck()
        {
            //loop through all the suits
            for (int suitVal = 0; suitVal < 4; suitVal++)
            {
                //loop through all the ranks
                for (int rankVal = 1; rankVal < 14; rankVal++)
                {
                    //add the card onto the deck
                    cards.Add(new Card((Suit)suitVal, (Rank)rankVal));
                }
            }
        }

        //returns a card at a specific position
        public Card GetCard(int cardNum)
            {
               if (cardNum >= 0 && cardNum <= 51)
                  return cards[cardNum];
               else
                  throw (new System.ArgumentOutOfRangeException("cardNum", cardNum,
                            "Value must be between 0 and 51."));
            }

        //meathod to suffle the deck
        public void Shuffle()
        {
            //create a new deck list
            Cards newDeck = new Cards();
            bool[] assigned = new bool[52];
            //assign a randomly generated number to sourceGen
            Random sourceGen = new Random();
            //loop through every position to look for specific card
            for (int i = 0; i < 52; i++)
            {
                int sourceCard = 0;
                bool foundCard = false;
                while (foundCard == false)
                {
                    sourceCard = sourceGen.Next(52);
                    if (assigned[sourceCard] == false)
                        foundCard = true;
                }
                assigned[sourceCard] = true;
                newDeck.Add(cards[sourceCard]);
            }
            //place the newly shuffled deck into the list
            newDeck.CopyTo(cards);
        }
    }
}