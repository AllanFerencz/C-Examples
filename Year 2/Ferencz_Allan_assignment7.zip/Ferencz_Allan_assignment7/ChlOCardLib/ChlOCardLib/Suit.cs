﻿//Name:              Allan Ferencz
//Date:              February 13, 2015
//Program Name:      Suit.cs
//Description:       This enumeration sets the standard for suits

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ch11CardLib
{
    public enum Suit
    {
        Club,
        Diamond,
        Heart,
        Spade,
    }
}