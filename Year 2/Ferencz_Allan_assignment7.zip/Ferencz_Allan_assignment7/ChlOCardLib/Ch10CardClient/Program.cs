﻿//Name:              Allan Ferencz
//Date:              March 6, 2015
//Program Name:      program.cs
//Description:       tect program to see if my card library is working
using Ch11CardLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch11CardClient
{
    class Program
    {
        static void Main(string[] args)
        { 
            //declare a new deck
            Deck deck1 = new Deck();
            //clone the deck
           Deck deck2 = (Deck)deck1.Clone();
            //output card in the first card in the first deck
           Console.WriteLine("The first card in the original deck is: {0}",
                             deck1.GetCard(0).ToString());
           //output card in the first card in the second deck
            Console.WriteLine("The first card in the cloned deck is: {0}",
                             deck2.GetCard(0).ToString());
            //shuffle the first deck
           deck1.Shuffle();
            //inform the user what happened
           Console.WriteLine("Original deck shuffled.");
           //output card in the first card in the first deck
           Console.WriteLine("The first card in the original deck is: {0}",
                             deck1.GetCard(0).ToString());
           //output card in the first card in the second deck
           Console.WriteLine("The first card in the cloned deck is: {0}",
                             deck2.GetCard(0).ToString());
            //wait for user to respone
           Console.ReadKey();




          
        }
    }
}