﻿//Name:              Allan Ferencz
//Date:              March 6, 2015
//Program Name:      program.cs
//Description:       tect program to see if my card library is working
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch11CardLib;

namespace TestProgram2
{
    class Program
    {
        static void Main(string[] args)
        {
            //sets the ace to high
            Card.isAceHigh = true;
            //inform the user of what happened
            Console.WriteLine("Aces are high.");
            //set trump cards to true
            Card.useTrumps = true;
            //sets trump to Club
            Card.trump = Suit.Club;
            //inform the user what happened
            Console.WriteLine("Clubs are trumps.");

            //declare 5 card objects
            Card card1, card2, card3, card4, card5;
            //set the card objects
            card1 = new Card(Suit.Club, Rank.Five);
            card2 = new Card(Suit.Club, Rank.Five);
            card3 = new Card(Suit.Club, Rank.Ace);
            card4 = new Card(Suit.Heart, Rank.Ten);
            card5 = new Card(Suit.Diamond, Rank.Ace);

            //this section below uses the overloaded operators to compare all the cards.
            //there is also a message to the user as to what was compared and what the out come of each was
            Console.WriteLine("{0} == {1} ? {2}",
                 card1.ToString(), card2.ToString(), card1 == card2); //using equality operator
            Console.WriteLine("{0} != {1} ? {2}",
                 card1.ToString(), card3.ToString(), card1 != card3); //using not equal to operator
            Console.WriteLine("{0}.Equals({1}) ? {2}",
                 card1.ToString(), card4.ToString(), card1.Equals(card4)); //using .Equals to operator
            Console.WriteLine("Card.Equals({0}, {1}) ? {2}",
                 card3.ToString(), card4.ToString(), Card.Equals(card3, card4)); //using .Equals to operator
            Console.WriteLine("{0} > {1} ? {2}",
                 card1.ToString(), card2.ToString(), card1 > card2); //using greater than operator
            Console.WriteLine("{0} <= {1} ? {2}",
                 card1.ToString(), card3.ToString(), card1 <= card3); // using less than or equal too operator
            Console.WriteLine("{0} > {1} ? {2}",
                 card1.ToString(), card4.ToString(), card1 > card4);//using greater than operator
            Console.WriteLine("{0} > {1} ? {2}",
                 card4.ToString(), card1.ToString(), card4 > card1);//using greater than operator
            Console.WriteLine("{0} > {1} ? {2}",
                 card5.ToString(), card4.ToString(), card5 > card4);//using greater than operator
            Console.WriteLine("{0} > {1} ? {2}",
                 card4.ToString(), card5.ToString(), card4 > card5);//using greater than operator
            Console.ReadKey(); // wait for user input

        }
    }
}
