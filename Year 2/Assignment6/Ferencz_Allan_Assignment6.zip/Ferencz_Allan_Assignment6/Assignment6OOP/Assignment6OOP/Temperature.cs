﻿//Name:              Allan Ferencz
//Date:              February 20, 2015
//Program Name:      Temperature.cs
//Description:       Tempature enumeration

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment6OOP
{
    public enum Temperature : byte
    {
        //enumeration for the tempature of the beverage
        Hot,
        Cold,
        Warm 
    }
}
