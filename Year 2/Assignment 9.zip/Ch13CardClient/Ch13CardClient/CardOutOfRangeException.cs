﻿//Name:              Allan Ferencz
//Date:              March 20, 2015
//Program Name:      CardOutOfRangeException.cs
//Description:       this class is for when card is out of range, it throws an exception

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch13CardClient
{
    public class CardOutOfRangeException : Exception
    {
        //holds the deck
        private Cards deckContents;

        public Cards DeckContents //method to return the contents  of the deck
        {
            get
            {
                return deckContents;
            }
        }

        //exception called CardOutOfRangeException and it takes a cards object
        public CardOutOfRangeException(Cards sourceDeckContents)
            : base("There are only 52 cards in the deck.") // calls the base class which than goes to the event handler for CardOutOfRangeException
        {
            //sets the deck contents to the deck past to it
            deckContents = sourceDeckContents;
        }
    }
}
