﻿//Name:              Allan Ferencz
//Date:              February 13, 2015
//Program Name:      cards.cs
//Description:       this holds the deck of cards

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Ch13CardClient
{
    //using collection base for list and icloneable for cloning
    public class Cards : CollectionBase, ICloneable
    {
        public object Clone()
        {
            //declare a new list called newCards
            Cards newCards = new Cards();
            foreach (Card sourceCard in List) //loop through each position to clone the card
            {
                newCards.Add((Card)sourceCard.Clone());
            }
            return newCards; // return the new cloned list
        }

        //add a new card to the list
        public void Add(Card newCard)
        {
            List.Add(newCard);
        }

        //remove a card from the list
        public void Remove(Card oldCard)
        {
            List.Remove(oldCard);
        }

        //find a card at a position
        public Card this[int cardIndex]
        {
            get
            {
                //return a care at the index you are looking for
                return (Card)List[cardIndex];
            }
            set
            {
                //places the card values into a list at index you sent it
                List[cardIndex] = value;
            }
        }

        /// <summary>
        /// Utility method for copying card instances into another Cards
        /// instance—used in Deck.Shuffle(). This implementation assumes that
        /// source and target collections are the same size.
        /// </summary>
        public void CopyTo(Cards targetCards)
        {
            for (int index = 0; index < this.Count; index++)
            {
                targetCards[index] = this[index];
            }
        }

        /// <summary>
        /// Check to see if the Cards collection contains a particular card.
        /// This calls the Contains() method of the ArrayList for the collection,
        /// which you access through the InnerList property.
        /// </summary>
        public bool Contains(Card card)
        {
            return InnerList.Contains(card);
        }
    }
}
