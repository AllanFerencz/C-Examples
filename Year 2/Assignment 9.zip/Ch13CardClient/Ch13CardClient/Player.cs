﻿//Name:              Allan Ferencz
//Date:              March 20, 2015
//Program Name:      Player.cs
//Description:       Holds the Player data

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch13CardClient
{
    public class Player
    {
        //hold a players name
        public string Name { get; private set; }
        //hold a play hand
        public Cards PlayHand { get; private set; }
        //default constructor
        private Player()
        {
        }
        //parameterised constructor for Player
        public Player(string name)
        {
            //set the class Name to the name that was set
            Name = name;
            //create a new array of card for the players hand
            PlayHand = new Cards();
        }

        //method to declare a player has won
        public bool HasWon()
        {
            //sets a bool called won to true
            bool won = true;
            // sets a suit enumeration to playHand at position 0 suit
            Suit match = PlayHand[0].suit;
            //loop through the play hand
            for (int i = 1; i < PlayHand.Count; i++)
            {
                won &= PlayHand[i].suit == match; // checks if the card is equal to the suit
            }
            return won; //return true or false depending on if her won or not
        }
    }
}