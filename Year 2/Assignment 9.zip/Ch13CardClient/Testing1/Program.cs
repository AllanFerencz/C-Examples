﻿//Name:              Allan Ferencz
//Date:              March 20, 2015
//Program Name:      program.cs
//Description:       demonstrates the out of range exception

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch13CardClient;

namespace Testing1
{
    class Program
    {
        static void Main(string[] args)
        {
            //initialise a Deck object 
            Deck deck1 = new Deck();
            try
            {
                //try to make myCard equal to the card at index of 60
                Card myCard = deck1.GetCard(60);
            }
            catch (CardOutOfRangeException e)
            {
                //Writes out the error message for the Card out of range exception
                Console.WriteLine(e.Message);
                //will show the contents of the deck
                Console.WriteLine(e.DeckContents[0]);
            }
            Console.ReadKey();

        }
    }
}
