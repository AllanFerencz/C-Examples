﻿// Student Name: Allan Ferencz
// Program Name: Assignmennt3
//         Date: 2015-01-30
//  Description: This program is designed to have the user enter in 5 Grades.
//               The user can enter in what the would like show beside the grade.
//               Either a letterGrade or a Description of the grade. The program than show stats for the grades.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        
        //Deligate to for PercentToLetterGrade or PercentToDescription. Will pick one depending on what the user inputs.
        public delegate string PercentToFeedback(double grade);

        //Takes in a grade and returns a letter grade depending on the grade you sent it.
        public static string PercentToLetterGrade(double grade)
        {
            string letterGrade = "F";

            if (grade >90 && grade < 100)
            {
                letterGrade = "A+";
            }
            else if (grade > 85)
            {
                letterGrade = "A";
            }
            else if (grade > 80)
            {
                letterGrade = "A-";
            }
            else if (grade > 75)
            {
                letterGrade = "B+";
            }
            else if (grade > 70)
            {
                letterGrade = "B";
            }
            else if (grade > 65)
            {
                letterGrade = "C+";
            }
            else if (grade > 60)
            {
                letterGrade = "C";
            }
            else if (grade > 55)
            {
                letterGrade = "D+";
            }
            else if (grade > 50)
            {
                letterGrade = "D";
            }
            else if (grade >= 0)
            {
                letterGrade = "F";
            }
            else
            {
                letterGrade = "Invalid";
            }

            return letterGrade;
        }

        //Takes in a grade and returns a grade description depending on the grade you sent it.
        public static string PercentToDescription(double grade)
        {
            string gradeDescription;

            if (grade > 90 && grade < 100)
            {
                gradeDescription = "Outstanding";
            }
            else if (grade > 85)
            {
                gradeDescription = "Exemplary";
            }
            else if (grade > 80)
            {
                gradeDescription = "Excellent";
            }
            else if (grade > 75)
            {
                gradeDescription = "Very Good";
            }
            else if (grade > 70)
            {
                gradeDescription = "Good";
            }
            else if (grade > 65)
            {
                gradeDescription = "Satisfactory";
            }
            else if (grade > 60)
            {
                gradeDescription = "Acceptable";
            }
            else if (grade > 55)
            {
                gradeDescription = "Conditional Pass";
            }
            else if (grade > 50)
            {
                gradeDescription = "Conditional Pass";
            }
            else if (grade >= 0)
            {
                gradeDescription = "Failure";
            }
            else
            {
                gradeDescription = "Invalid";
            }

            return gradeDescription;
        }

        //Struct to hold the stats of the grades.
        public struct GradeStats
        {
            public double averageGrade;
            public int passingGrades;
            public int failingGrades;
            public int invalidGrades;

        }
        //Function to Calculate stats of the grades. Will take in the struct and refer to the memory location of it.
        //will also take an array of grades. Will loop through all the grades and calculate the stats for that grade.
        //Will return an int that shows how many grades were processed.
        public static int CalculateGradeStats(double[] grades, ref GradeStats stats)
        {
            int gradesProcessed;

            for (gradesProcessed = 0; gradesProcessed < grades.Length; gradesProcessed++)
            {
                //adds to passing grade
                if (grades[gradesProcessed] <= 100 && grades[gradesProcessed] > 50)
                {
                    stats.passingGrades++;
                    stats.averageGrade += grades[gradesProcessed];
                }
                //adds to failing grade
                else if (grades[gradesProcessed] < 50 && grades[gradesProcessed] >= 0)
                {
                    stats.failingGrades++;
                    stats.averageGrade += grades[gradesProcessed];
                }
                //adds to invalid grade
                else
                {
                    stats.invalidGrades++;
                }

            }
            //Calculates the average grade of only non invalid grades
            stats.averageGrade = stats.averageGrade / (gradesProcessed - stats.invalidGrades);

            return gradesProcessed;
        }

        //show the grades in a report. Will take an array of grades and a PercentToFeedback for my deligate to pick what to display beside the grade.
        //Nothing is returned but report gets sent to console display.
        public static void ShowGradeReport(double[] grades, PercentToFeedback functionName)
        {
            int gradesProcessed;
            GradeStats stats = new GradeStats(); // Make a new Struct to save the grade stats too.
            gradesProcessed = CalculateGradeStats(grades, ref stats); // Calculates the grades stats by using the CalculateGradeStats function
            for ( int i = 0; i < grades.Length; i++)
            {
                Console.WriteLine("Student  " + (i+1) + ":  " + grades[i] + "%  :  " + functionName(grades[i]));  // displays to console the grade with users desired message.

            }

            //User output 
            Console.WriteLine("\nNumber of grades processed is:   " + gradesProcessed); 
            Console.WriteLine(  "The Average Grade is:            " + stats.averageGrade + "%");
            Console.WriteLine(  "The number of passing Grades is: " + stats.passingGrades);
            Console.WriteLine(  "The number of failing Grades is: " + stats.failingGrades);
            Console.WriteLine(  "The number of invalid Grades is: " + stats.invalidGrades);
           
        }
        static void Main(string[] args)
        {
            int numberOfGrades = 0; // set the number of grades to 0 
            double[] grades = new double[5]; // Set the number of grades to be entered at 5
            string userInput; //Holds what the user inputs
            PercentToFeedback format = new PercentToFeedback(PercentToLetterGrade); // delagate variable to pick what the text the user wants is
            
            //output
            Console.WriteLine("Enter in \"description\"  to see the Descriptions of the grade.\nEnter in anything else for Letter grade display.\n");
            userInput = Console.ReadLine();
            if (userInput == "description") // if user enters in description than they want the grades to have descriptions beside them.
            {
                try // try to swap the delagate
                {
                    format = new PercentToFeedback(PercentToDescription);
                }
                catch // error messages
                {
                    Console.WriteLine("Error changing to Description");
                }
            }

            // while grades is less than 5
            while(numberOfGrades<5)
            {
                //Display to user the grade number they are entering
                Console.WriteLine("Enter in a grade for Student " + (numberOfGrades + 1));
                userInput = Console.ReadLine();

                try
                {
                    //try to convert what they entered to a number
                    grades[numberOfGrades] = Convert.ToDouble(userInput);
                    //add one to numberOfGrades if the grade was a valid grade
                    numberOfGrades++;

                }
                catch(Exception)
                {
                    // error message
                    Console.WriteLine("Input must be a number");
                }

            }
            Console.WriteLine("\n");
            // run ShowGradeReport and wait for users input
            ShowGradeReport(grades, format);
            Console.ReadKey();

        }
    }
}
