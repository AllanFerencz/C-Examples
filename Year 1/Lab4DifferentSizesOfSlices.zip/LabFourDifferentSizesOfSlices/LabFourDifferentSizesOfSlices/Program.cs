﻿/* Program Name:            LabFourDifferentSizesOfSlices
 * Program Auther:          Allan Ferencz/ Alexander Plant 
 * Date:                    November 2, 2013
 * 
 * Descrption:              A console application that asks the user for the Dimeter of their pizza
 *                          will then find the correct amount of slices for that the pizza can be 
 *                          cut by. will then display the number of slices and area for all the different sizes.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabFourDifferentSizesOfSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            /*--------------------------------------------
             * VARIABLE DECLERATION AND ASSIGNMENTS
             * -------------------------------------------
             */
           
            string userInput = "";          //a string variable to temporaily hold user input
            const string EXIT = "0";        //a constant to end the program
            double sliceArea;               //a decimal variable to hold area of a slice
            double pizzaDiameter;           //a decimal variable that holds the Diameter of the pizza
            double pizzaArea;               //a decimal variable that holds the area of the pizza
            int loopEndValue;               //a variable to hold the end value of the do while loop
            const int MIN_DIAMETER = 12;    //a constant that holds the smallest Diameter size 
            const int SMALL_DIAMETER = 20;  //a constant that holds the small Diameter size 
            const int MED_DIAMETER = 24;    //a constant that holds the medium Diameter size      
            const int LARGE_DIAMETER = 30;  //a constant that holds the large Diameter size
            const int MAX_DIAMETER = 36;    //a constant that holds the Biggest Diameter size


            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */

            Console.WriteLine("What is the Diameter of your pizza");//Displays a message to the user to enter the Diameter of there pizza
            userInput = Console.ReadLine(); //User enters a Diameter and its saved in to userInput

            /* -----------------------------------------
            * Processing
            * -----------------------------------------
            */


            while (userInput != EXIT) //Loops till userInput is equal to EXIT
            {

            Console.Clear();  //Clears screen to clean up old displays 
                if (double.TryParse(userInput, out pizzaDiameter)) //Trys to parse userInput into pizzaDiameter if it can't then its not a number
                {
                    if (pizzaDiameter >= MIN_DIAMETER && pizzaDiameter <= MAX_DIAMETER) //checks if pizzaDiameter is a number that is within MIN_DIAMETER and MAX_DIAMETER
                    {
                        pizzaArea = Math.PI * ((pizzaDiameter / 2) * (pizzaDiameter / 2)); //finds the area of the pizza and puts that value in to pizzaArea

                        //The if loop Finds how many times the for loop needs to be displayed
                        
                        if (pizzaDiameter >= LARGE_DIAMETER) //checks if the Diameter is greater than 30
                        {
                            loopEndValue = 5; //Sets the for loop to end after 5 runs
                        }
                        else if (pizzaDiameter >= MED_DIAMETER) //checks if the Diameter is greater than 24
                        {
                            loopEndValue = 3; //Sets the for loop to end after 3 runs
                        }
                        else if (pizzaDiameter >= SMALL_DIAMETER) //checks if the Diameter is greater than 20
                        {
                            loopEndValue = 2; //Sets the for loop to end after 2 runs
                        }
                        else //if nothing else then it is the smallest size pizza
                        {
                            loopEndValue = 1; //Sets the for loop to end after 1 runs
                        }

                        /* -----------------------------------------
                         * Output
                         * -----------------------------------------
                         */

                        Console.WriteLine("Pizza Diameter :" + pizzaDiameter + "\n"); // Shows the user the Diameter they entered
                       
                        /* -----------------------------------------
                         * Processing
                         * -----------------------------------------
                         */

                        for (int count = 1, slices = 8; count <= loopEndValue; count++, slices += +4) // Variables to hold the count of the for loop and how many slices to divide by. Also the loop ends when count is Equal to loopEndValue
                        {
                            sliceArea = Math.Round(pizzaArea / slices, 2); // rounds the area of a slice to 2 decimals

                            /* -----------------------------------------
                             * Output
                             * -----------------------------------------
                             */
                            
                            Console.WriteLine("Cut in " + slices + " Slices results in a slice area of " + sliceArea + "\" per slice"); // displays to the user the area of each slice depending on the number of slices displayed

                            /* -----------------------------------------
                             * Processing
                             * -----------------------------------------
                             */                          
                        }

                    }
                    else // if diameter is not between MIN_DIAMETER AND MAX_DIAMETER
                    {
                        /* -----------------------------------------
                         * Output
                         * -----------------------------------------
                         */

                        Console.WriteLine("Diameter entered must be between " + MIN_DIAMETER + " and " + MAX_DIAMETER);
                    }

                }

                else // if diameter entered is not a number 
                {
                    /* -----------------------------------------
                     * Output
                     * -----------------------------------------
                     */

                    Console.WriteLine("Diameter entered must be a number"); //displays to the user that they didn't enter a number
                }
                /* -----------------------------------------
                 * Output
                 * -----------------------------------------
                 */

            Console.WriteLine("\nEnter another diameter or " + EXIT + " to end the program");//displays to the user they can enetr another diameter or the EXIT constant to exit the program
            userInput = Console.ReadLine(); //User enters a Diameter and its saved in to userInput
            }    
        }
    }
}
