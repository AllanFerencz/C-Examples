﻿/* Program Name:            LabFiveBowlingScores
 * Program Auther:          Allan Ferencz/ Julien Ouimet
 * Date:                    November 17, 2013
 * 
 * Descrption:              A console application that asks the user for 5 different bowling scores and sorts them
 *                          by highest lowest and the average score
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabFiveBowlingScores
{
    class Program
    {
        static void Main(string[] args)
        {
            /*--------------------------------------------
             * VARIABLE DECLERATION AND ASSIGNMENTS
             * -------------------------------------------
             */

            string userInput;           //For holding the user input
            int highestScore = 0;       // For holding the highest score
            int lowestScore = 300;      // For holding the Lowest Score
            double averageScore = 0;        //For holing the average of all the scores
            int count = 0; //holds the current count of the for loop
            const int BOWLING_SCORE_COUNT = 5; //Holds the end value of the for loop/array
            int[] bowlingScores = new int[BOWLING_SCORE_COUNT]; //Holds the bowling scores

            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */

            while (count < BOWLING_SCORE_COUNT) //LOOP to fill up the bowling score array 
            {
                Console.WriteLine("Please enter score for series " + (count + 1)); // Promt user for scores
                userInput = Console.ReadLine();
                if (int.TryParse(userInput, out bowlingScores[count])) // checks if score can be put in to a int data type from a string
                {
                    if (bowlingScores[count] <= 300 && bowlingScores[count] >= 0) //if the score is over 300 or less than 0 will promt user for a new score
                    {
                    }
                    else
                    {
                        Console.WriteLine("Score must be between 0 and 300. Please try again."); // Error msg 
                        count -= 1; // Lowers the count by one to over write the incorrect input
                    }
                }
                else
                {
                    Console.WriteLine("Scores must be numeric, whole numbers only, no decimals..Please try again."); // Error msg
                    count -= 1; // Lowers the count by one to over write the incorrect input
                }
                count += 1; // to proced to the next spot to fill
            }

            /* -----------------------------------------
             * Processing
             * -----------------------------------------
             */

            count = 0; // Resets count

            while (count < BOWLING_SCORE_COUNT) //LOOP to fill up the highest, lowest, and average scores 
            {
                if (bowlingScores[count] < lowestScore) // checks if the score is lower than the current lowest score
                {
                    lowestScore = bowlingScores[count]; // replaces the previous score with the new lowest score
                }
                if (bowlingScores[count] > highestScore)// checks if the score is higher than the current highest score
                {
                    highestScore = bowlingScores[count];// replaces the previous score with the new highest score
                }
                averageScore = averageScore + (Convert.ToDouble(bowlingScores[count])); //Accumulating all the scores for the average
                count += 1; // to proced to the next spot to fill
            }

            averageScore = averageScore / BOWLING_SCORE_COUNT; // calculating the average score
            averageScore = Math.Round(averageScore); // rounding the score because you can't have half a pin
            count = 0;// Resets count

            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */

            Console.Clear(); // Clears screen for the finial output

            Console.WriteLine("Bowler Scores");// formatting
            Console.WriteLine("===============================================================\n");// formatting
           
            while (count < BOWLING_SCORE_COUNT) // displaying the scores
            {
                Console.Write("Game " + (count+ 1) + ": " + bowlingScores[count] + " ");
                count += 1; // to select the next score to display 
            }

            Console.WriteLine("\n");// formatting
            Console.WriteLine("===============================================================\n");// formatting
            Console.WriteLine("Average Score for Bowler : " + averageScore + "\n"); // Display average score
            Console.WriteLine("High Score for Bowler : " + highestScore + "\n");// Display highest score
            Console.WriteLine("Low Score for Bowler : " + lowestScore + "\n");// display lowest score
            
            // Prompt the user to press "Any Key" to end the program
            Console.Write("\n\nPress Any Key to Exit....");
            // Pause for the entry of any key character
            Console.ReadKey();

        }
    }
}
