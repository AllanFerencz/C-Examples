﻿/* Program Name:            LabTwoPizzaSlices
 * Program Auther:          Alexander Plant/Allan Ferencz 
 * Date:                    September 20, 2013
 * 
 * Descrption:              A console application that asks the user for the diameter of a pizza and 
 *                          will display the amount of slices you can get from that pizza.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTwoPizzaSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            /*--------------------------------------------
             * VARIABLE DECLERATION AND ASSIGNMENTS
             * -------------------------------------------
             */

            // Declare variables to hold Diameter of pizza, the amount of slices you can have from one pizza, area of the pizza and area of one slice
            
            int slices;                 //a whole number that Holds the amount of slices that you can get from the pizza
            double pizzaDiameter;       //a real number that Holds the diameter of the pizza               
            double pizzaArea;           //a real number that Holds the area of the pizza
            const double SLICE_AREA = 14.125;    //a real constant that holds and declares the area of a slice
                        
            
            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */            
            
            //Displays the message to the user that the program needs the diameter of the pizza
            Console.WriteLine("Enter the diameter of your pizza");
            //Puts the diameter of thee pizza in to the pizzaDiameter variable
            pizzaDiameter = Convert.ToDouble(Console.ReadLine());

            /* -----------------------------------------
             * Processing
             * -----------------------------------------
             */

            // Calculates the area of the pizza
            pizzaArea = Math.PI * ((pizzaDiameter / 2)*(pizzaDiameter / 2));
            // Calculates the number of slices
            slices = Convert.ToInt32(Math.Floor(pizzaArea / SLICE_AREA));

            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */

            // Displays the amount of slices the user can get with their diameter they entered
            Console.WriteLine("\nThe amount of slices you can get from a pizza with a diameter of " + pizzaDiameter + " inches is " + slices);

            // Prompt the user to press "Any Key" to end the program
            Console.Write("\n\nPress Any Key to Exit....");
            // Pause for the entry of any key character
            Console.ReadKey();

        }
    }
}
