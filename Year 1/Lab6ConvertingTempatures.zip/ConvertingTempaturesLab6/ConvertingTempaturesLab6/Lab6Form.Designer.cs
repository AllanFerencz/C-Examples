﻿namespace ConvertingTempaturesLab6
{
    partial class frmTempConvert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblValueConvert = new System.Windows.Forms.Label();
            this.objCel = new System.Windows.Forms.RadioButton();
            this.txtTempInput = new System.Windows.Forms.TextBox();
            this.objFah = new System.Windows.Forms.RadioButton();
            this.lblDisplayConversion = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(28, 113);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 31);
            this.btnConvert.TabIndex = 4;
            this.btnConvert.Text = "&Convert";
            this.toolTip1.SetToolTip(this.btnConvert, "Calculates new value");
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(138, 113);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 31);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clea&r";
            this.toolTip1.SetToolTip(this.btnClear, "Clear all setting/text");
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(246, 113);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 31);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.toolTip1.SetToolTip(this.btnExit, "Exit the program");
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblValueConvert
            // 
            this.lblValueConvert.Location = new System.Drawing.Point(25, 0);
            this.lblValueConvert.Name = "lblValueConvert";
            this.lblValueConvert.Size = new System.Drawing.Size(113, 37);
            this.lblValueConvert.TabIndex = 0;
            this.lblValueConvert.Text = "&Value to Convert";
            this.lblValueConvert.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblValueConvert, "Enter Value in box below");
            // 
            // objCel
            // 
            this.objCel.Checked = true;
            this.objCel.Location = new System.Drawing.Point(155, 13);
            this.objCel.Name = "objCel";
            this.objCel.Size = new System.Drawing.Size(153, 24);
            this.objCel.TabIndex = 2;
            this.objCel.TabStop = true;
            this.objCel.Text = "Con&vert to Celsius";
            this.toolTip1.SetToolTip(this.objCel, "Changes Value to Celsius");
            this.objCel.UseVisualStyleBackColor = true;
            this.objCel.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // txtTempInput
            // 
            this.txtTempInput.Location = new System.Drawing.Point(29, 39);
            this.txtTempInput.Name = "txtTempInput";
            this.txtTempInput.Size = new System.Drawing.Size(100, 22);
            this.txtTempInput.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtTempInput, "Input Tempature");
            // 
            // objFah
            // 
            this.objFah.AutoSize = true;
            this.objFah.Location = new System.Drawing.Point(155, 40);
            this.objFah.Name = "objFah";
            this.objFah.Size = new System.Drawing.Size(166, 21);
            this.objFah.TabIndex = 3;
            this.objFah.Text = "Convert to &Fahrenheit";
            this.toolTip1.SetToolTip(this.objFah, "Changes Value to Fahrenheit");
            this.objFah.UseVisualStyleBackColor = true;
            this.objFah.CheckedChanged += new System.EventHandler(this.objFah_CheckedChanged);
            // 
            // lblDisplayConversion
            // 
            this.lblDisplayConversion.AutoSize = true;
            this.lblDisplayConversion.Location = new System.Drawing.Point(25, 77);
            this.lblDisplayConversion.Name = "lblDisplayConversion";
            this.lblDisplayConversion.Size = new System.Drawing.Size(0, 17);
            this.lblDisplayConversion.TabIndex = 7;
            this.lblDisplayConversion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip1.SetToolTip(this.lblDisplayConversion, "Converted tempature");
            this.lblDisplayConversion.Click += new System.EventHandler(this.label2_Click);
            // 
            // frmTempConvert
            // 
            this.AcceptButton = this.btnConvert;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 156);
            this.ControlBox = false;
            this.Controls.Add(this.lblDisplayConversion);
            this.Controls.Add(this.objFah);
            this.Controls.Add(this.txtTempInput);
            this.Controls.Add(this.objCel);
            this.Controls.Add(this.lblValueConvert);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnConvert);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTempConvert";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Temperature Convertor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblValueConvert;
        private System.Windows.Forms.RadioButton objCel;
        private System.Windows.Forms.TextBox txtTempInput;
        private System.Windows.Forms.RadioButton objFah;
        private System.Windows.Forms.Label lblDisplayConversion;
        private System.Windows.Forms.ToolTip toolTip1;
        

        /// <summary>
        /// method for taking in a tempature value and returning its fahrenheit or celsius counter part.
        /// </summary>
        /// <param name="temp">The tempature that is being changed</param>
        /// <param name="convertCelius">boolean to determine if it needs to be calculated to Celius or not</param>
        /// <returns>The new tempature after it was converter to its counter part</returns>
        public double Convertor(double temp , bool convertCelius)
        {
          if (convertCelius == true)
          {
              temp = ((temp - 32) * 5)/9;
          }
          else
          {
              temp = (temp * 9) / 5 + 32;
          }
          return temp;
        }
        

    }
}

