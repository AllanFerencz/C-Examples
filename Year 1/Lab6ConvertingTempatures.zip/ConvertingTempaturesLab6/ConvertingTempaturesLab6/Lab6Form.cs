﻿/* Program Name:            ConvertingTempaturesLab6
 * Program Auther:          Allan Ferencz/ Alexander Plant 
 * Date:                    Dec 6, 2013
 * 
 * Descrption:              A Form application that allows the user to enter in a tampature
 *                          and have it converted to Celsius or fahrenheit. 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvertingTempaturesLab6
{
    public partial class frmTempConvert : Form
    {
        public frmTempConvert()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double tempValue; // Holds the Value of the tempature
            string userInput = txtTempInput.Text; // Holds the value of the tempature when retrieving and returning to text box
            bool rdoButtonCel; // Bool to hold that Celsius btn is check


            if (double.TryParse(userInput, out tempValue)) // Check if the user entered a letter or number
            {

                if (objCel.Checked == true) // to deside if the radio btn for celsius or fah is checked
                {
                    rdoButtonCel = true; // sets the bool to true because celsius btn was checked
                    tempValue = Convertor(tempValue, rdoButtonCel); // send values to method to have it calculated
                    tempValue = Math.Round(tempValue, 1);//rounds the returned value to 2 decimals
                    userInput = tempValue + "° C"; // adds the correct tempature for the user
                }
                else // if the user doesn't have celsius btn checked than they want to calculate Fahren
                {
                    rdoButtonCel = false; //sets the Celsius btn to false because its not checked
                    tempValue = Convertor(tempValue, rdoButtonCel); // send values to method to have it calculated and saves it in temp 
                    tempValue = Math.Round(tempValue, 1);//rounds the returned value to 2 decimals
                    userInput = tempValue + "° F";// adds the correct tempature for the user
                }
                lblDisplayConversion.Text = userInput; // Changes the lbl to the converted tempature
            }
            else // if number was not entered 
            {
                // ERROR msg would have been the required "ERROR: Please enter a numeric tempature to convert" but it was too long and you wanted it to look professional and going off the form looks bad
                lblDisplayConversion.Text = "ERROR: Please enter a number to convert"; // error msg to the user they need to enter a number
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // Closes program
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTempInput.Text = ""; //clears the current value to nothing
            lblDisplayConversion.Text = "";//clears the current value to nothing
            txtTempInput.Focus(); // sets focus on the text box

        }

        private void objFah_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
