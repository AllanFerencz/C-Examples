﻿/* Program Name:            LabThreePizzaDiameterToSlices
 * Program Auther:          Allan Ferencz/ Ted Warda  
 * Date:                    October 14, 2013
 * 
 * Descrption:              A console application that asks the user for the Dimeter of their pizza
 *                          will then find the correct amount of slices for that diameter. then 
 *                          display the number of slices and the area of each slice.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabThreePizzaDiameterToSlices
{
    class Program
    {
        static void Main(string[] args)
        {
            /*--------------------------------------------
             * VARIABLE DECLERATION AND ASSIGNMENTS
             * -------------------------------------------
             */

            //double numberTryParse;        //holds weather or not the user entered a number or letter
            string userInput;               //Holds the users input
            double diaOfPizza;              //Holds the diameter of the pizza
            int slices;                     //Holds the amount of slices
            double pizzaArea;               //Holds the area of the whole pizza
            double sliceArea;               //Holds the area of just one slice of pizza
            const int MIN_INCHES = 12;      //Holds the smallest required diameter of the pizza
            const int SMALL_INCHES = 16;    //Holds the small required diameter of the pizza
            const int MED_INCHES = 24;      //Holds the medium required diameter of the pizza
            const int LARGE_INCHES = 30;    //Holds the large required diameter of the pizza
            const int MAX_INCHES = 36;      //Holds the Maximum required diameter of the pizza
            
            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */ 

            //Displays a message to the user that the program needs a diameter of there pizza
            Console.WriteLine("Enter the Diameter of your pizza");
            //Puts the diameter of thee pizza in to the userInput variable
            userInput = Console.ReadLine();

            /* -----------------------------------------
             * Processing
             * -----------------------------------------
             */
            
            //Checks if the user entered a number or a non-number character
            if (double.TryParse(userInput, out diaOfPizza)) // will put userinput into diaOfPizza but only if it is a number
            {
                if (diaOfPizza > MIN_INCHES && diaOfPizza < MAX_INCHES) //Checks if the number is within 12-36
                {
                    //Find the amount of slices that is correct for the pizza
                    if (diaOfPizza > MIN_INCHES && diaOfPizza < SMALL_INCHES)
                    {
                        slices = 8;
                    }
                    else if (diaOfPizza > SMALL_INCHES && diaOfPizza < MED_INCHES)
                    {
                        slices = 12;
                    }
                    else if (diaOfPizza > MED_INCHES && diaOfPizza < LARGE_INCHES)
                    {
                        slices = 16;
                    }
                    else
                    {
                        slices = 24;
                    }
                    
                    //Finds the total area of the entire pizza
                    pizzaArea = Math.PI * ((diaOfPizza / 2) * (diaOfPizza / 2));
                    //Takes the area of the pizza and divides it by the amount of slices to find area of one slice
                    sliceArea = Math.Round( pizzaArea / slices, 2);
                   
                    /* -----------------------------------------
                     * Output
                     * -----------------------------------------
                     */
                    
                    //Displays the diameter of the pizza and the amount of slices it will yeild
                    Console.WriteLine("A " + diaOfPizza + "\" pizza will yield " + slices + " slices.");
                    //Displays the Area that each slice will have
                    Console.WriteLine("Each slice will have an area of " + sliceArea + "\". ");
                }
                else
                {
                    Console.WriteLine("invalid input please enter a number within the range 12-36 "); //Tells the user they had an invalid input
                }
            }
            else
            {
                Console.WriteLine("invalid input please enter a number"); //Tells the user they had an invalid input
            }
           
            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */
            
            // Prompt the user to press "Any Key" to end the program
            Console.Write("\n\nPress Any Key to Exit....");
            // Pause for the entry of any key character
            Console.ReadKey();
        }
    }
}
