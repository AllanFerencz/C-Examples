﻿/* Program Name:            LabOne
 * Program Auther:          Allan Ferencz  
 * Date:                    September 11, 2013
 * 
 * Descrption:              A console application that displays the authers name, the college I am attending 
 *                          and the number of years of my program, also prompts the user to press any key to exit.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabOne
{
    class Program
    {
        static void Main(string[] args)
        {
            /*-------------------------------------------
            * VARIABLE DECLERATION AND ASSIGNMENTS
            * -------------------------------------------
            */

            // Declare variables to hold school, program and course information

            string myName;                       // Holds my first and last name
            string myProgram;                    // Holds the name of my program
            int programYears;                    // Holds the number of year my program is

            // Assign my name to myName variable
            myName = "Allan Ferencz";
            // Assign my programs name to myProgram variable
            myProgram = "Computer Programmer Analyst";
            // Assign the total years for my program to the programYears variable
            programYears = 3;

            /* -----------------------------------------
             * Output
             * -----------------------------------------
             */

            // Displays my name with identifier, to the console
            Console.WriteLine("Name: " + myName);
            // Displays my program name with identifier, to the console
            Console.WriteLine("Program: " + myProgram);
            // Displays my total years with identifier, to the console
            Console.WriteLine("Years to completion: " + programYears);

            // Prompt the user to press "Any Key" to end the program
            Console.Write("\n\nPress Any Key to Exit....");
            // Pause for the entry of any key character
            Console.ReadKey();

        }
    }
}
